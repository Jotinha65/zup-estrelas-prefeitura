package br.com.zup.estrelas.prefeitura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrefeituraApplicationTests {

	@Test
	void contextLoads() {
	}

}
