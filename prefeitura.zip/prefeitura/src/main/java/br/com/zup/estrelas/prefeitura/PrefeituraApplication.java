package br.com.zup.estrelas.prefeitura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrefeituraApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrefeituraApplication.class, args);
	}

}
